<!DOCTYPE html>
<html lang="en">
<?php
	require("gfunctions2.php");
	
	/* 	STEP 0 of 9 Bring in the correct menu!
		If this page has children or siblings then bring in the menu file called after the respective parent.
		e.g. this page is Arnolds, then the parent is Hotels, therefore the line should read require("hotelsmenu.php"); */
	require("nullmenu.php"); 
	
	/* 	STEP 1 of 9 - set up the description of the amenity.  Edit the writing between the two
		blank lines, but be sure to leave the blank lines intact, and do NOT touch anything above 
		first blank line, or below the second blank line. Insert the characters <br><br> if you want 
		a new paragraph.*/
	   
	/*	Do NOT touch this line!!!!! */   $blurb = " 
	
The village of Dunfanaghy is situated on the beautiful shores of 
	Sheephaven Bay on the edge of the Atlantic Ocean, surrounded by Blue Flag beaches, and 
	overlooked by the majestic Derryveagh Mountains of Donegal.
	<br><br>
	Within the village you will find every amenity imaginable for when you take a break from the music. 
	There is a superb 18 hole links golf course, 
	surfing and surf schools, horse-riding, hill walking.
	<br><br>
	The village also has numerous superb shops, restaurants and art galleries.
	<br><br>
	Much more information to follow!
	"; /*	Do NOT touch this line!!!!! */
	
	/* 	STEP 2 of 9 Set up welcome message */
	$w1 = "Bluegrass And Nashville Dunfanaghy";
	$w2 = "About Dunfanaghy";
	$w3 = "Dunfanaghy, Co. Donegal";
	
	/* 	STEP 3 of 9 Set up headings - be sure to leave a space at end of $h1 */
	$h1 = "Charming Village  ";
	$h2 = "Beautiful Scenery";
	
	/* 	STEP 4 of 9 - Set up the sub-title of the page  - use the name of this file with spaces put back in
		where it is obvious - e.g. if this file is called healthandbeauty.php, 
		then $subtitle = "Health and Beauty";*/
	$subtitle = "About Dunfanaghy";	
	
	/* 	STEP 5 of 9 - define this page's parent file - without extension e.g. index, patsys, arnolds.
		Set to "" if no parent i.e. Home page.
		Used to create "Go Back" button */
	$parent = "";
	
	/* 	STEP 6 of 9 - define the text above the menu items - e.g. str1 = "Browse", str2 = "The Town"  */
	$menustr01 = "Browse";
	$menustr02 = "The Options";
	
	/* 	STEP 7 of 9 - define the text in the Footer - most of the time leave this as it is */
	$footerstr01 = "Dunfanaghy, Co Donegal Ver 04";
	
	/* 	Step 8 of 9 - define the website and phone number for this page - leave as blank if they don't exist. e.g. $phone = "";
		Also set level where 
		level = 0 - is top level
		level = 1 - is lower level with children
		level = 2 - is bottom level with no children 
		Set $largepic = 1 to display a large picture at top of page.
		Set $largepic = 0 to NOT display a large picture at top of page. */
	$website = "www.thebandfestival.com";
	$phone = "+353 74 91 36 609";
	$level = 1;
	$largepic = 1;
	
	/* 	STEP 9 of 9 - Set up the menu items. 
		Add this page to the appropriate menu file!!!!!! 
		DON'T THINK that you will do it later - go and do it NOW!!!!!!
		So - save the changes you have just done, go change the menu file, and then have a beer!! 
		And remember to upload BOTH files!!!!*/
	
	/* 	STEP for the future - These variables are for future use, so at present do NOT touch. At present they are passed to main function, but not used. */
	$extrastr = array();
	$extranumber = array();	
				
	/* 	Grab the name of this file to use to construct the file names of this page's photographs. */
	$filename = basename(__FILE__, ".php");
	
?>	

<head>	
	<!-- Create title of webpage using $subtitle defined above and main title of website defined
		 in gfunctions2.php. -->
	<?php
		LoadMetaData();
		AddPageTitle($subtitle);
		LinkCssFiles();
	?>
</head>

<body> 
	<!-- Do what it says on the tin! -->
	<?php
		LoadEverything( $blurb, $website, $phone, $level, $filename, $w1, $w2, $w3, $h1, $h2, $parent, $names, $menustr01, $menustr02, $footerstr01, $largepic, $extrastr, $extranumber )
	?>
</body>
</html>

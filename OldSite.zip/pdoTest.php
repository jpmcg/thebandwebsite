<?php
    //define ('dbHost', "localhost");
	//define ('dbUser', "root");
	//define ('dbPassword',"Eight88letters");
	//define ('db' ,"dunfanaghy");
    require_once('config.php');
    $db = new PDO('mysql:host='.dbHost.';dbname='.db.';charset=utf8mb4',dbUser,dbPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //Puts PDO into error mode - Errors are thrown and can be handled, rather than die()
    $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false); //turn off prepare emulation which is enabled in MySQL driver by default, but really should be turned off to use PDO safely and is really only usable if you are using an old version of MySQL

    if($db) echo "DB connect success<hr/>";
        else echo "fail";
    try{
        echo "Basic DB Operations<br/>";
        $insertSQL = "INSERT INTO mailing (email) VALUES ('email@pdo.com');";
        $insertResult = $db->exec($insertSQL);
        echo $insertResult." Record inserted<br/>";

        $result = $db->query('select * from mailing');
        echo $result->rowCount()." rows returned<br/>";
        //foreach iteration
        foreach ($result as $row) {
            echo $row['email']."<br/>";
        }

        $deleteSQL = "DELETE FROM mailing WHERE email='email@pdo.com'";
        $deleteResult = $db->exec($deleteSQL);
        echo $deleteResult." Record(s) deleted ";

    }   catch(PDOException $e){
        echo "error: ".$e->getMessage();
    }

    echo "<hr/>";
    echo "Prepared statment operations<br/>";

    try{
        $statement = $db->prepare("SELECT * FROM mailing WHERE id=:id");
        $statement->bindValue(':id', 1);
        $statement->execute();

        foreach ($statement as $row) {
            echo $row['email']."<br/>";
        }

        $spStatement = $db->prepare("CALL GetAllEmails()");
        $spStatement->execute();
        echo "executed<br/>";
        foreach ($spStatement as $row) {
            echo $row['email']."<br/>";
        }

    }
    catch(PDOException $e){
        echo "Error: ".$e->getMessage();
    }
?>
<?php

    function getDB()
    {
        $db = new PDO('mysql:host='.dbHost.';dbname='.db.';charset=utf8mb4',dbUser,dbPassword);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //Puts PDO into error mode - Errors are thrown and can be handled, rather than die()
        $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false); //turn off prepare emulation which is enabled in MySQL driver by default, but really should be turned off to use PDO safely and is really only usable if you are using an old version of MySQL

        return $db;
    }

    function redirectTo($url)
	{
		header("Location: ".$url) ;
		exit;
	}

    function isNullOrEmpty($param)
    {
        return (!isset($param) || empty($param));
    }

    function notNullOrEmpty($param)
    {
        return !isNullOrEmpty($param);
    }

?>
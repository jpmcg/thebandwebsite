	<?php
		// $names = array("Shops", "Eating Out", "Bars & Music", "Accommodation", "Dunfanaghy Area", "Landscape", "Sport & Leisure", "Health & Beauty", "Arts & Crafts", "Beaches", "Walks & Drives", "Festivals" ); 	 
		$names = array();
		$parent01 = basename(__FILE__, "menu.php");
	?>
<html>
<?php
    require_once('gfunctions2.php');
    require_once("indexmenu.php");
?>
<head>	
	<!-- Create title of webpage using $subtitle defined above and main title of website defined
		 in gfunctions2.php. -->
<?php
    $subtitle = "Home";	
	LoadMetaData();
	AddPageTitle($subtitle);
	LinkCssFiles();
?>
</head>
<?php


    $menuValues = array();	
			   
	LoadBanner();
	LoadNavigation($menuValues);
?>
<div class='container'>
    <div class='row box'>
        <div class='col-lg-12 text-center'>
            <hr/>
            <h2 class='intro-text text-center'>Join Our 
            <strong>Mailing List</strong>
            </h2>
            <hr/>
            <?php 
            if(isset($_GET['success']) && $_GET['success']=='False'){
                echo "<p>Oh dear... Sign Up Failed - Did you enter a valid email address?</p>";
                echo "<p>Contact info@thebandfestival.com and we'll get you added ASAP</p>";
            }
            else{
                echo " <p>Thanks for signing up!  We look forward to seeing you at the Band Festival.</p>";						
            }
            echo "<p><a href='http://dunfanaghy.info/testing/John/theBand/index.php'>Back to Festival Home Page</a></p>";
            ?>           
        </div>
    </div>
</div>
</html>

<?php
		define ('dbHost', "localhost");
		define ('dbUser', "root");
		define ('dbPassword',"Eight88letters");
		define ('db' ,"dunfanaghy");
?>
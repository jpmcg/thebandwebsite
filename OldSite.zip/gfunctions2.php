<?php
	//	require_once('php/Mobile_Detect.php');
		
		/* This is the functions file for THE BAND FESTIVAL */
		function Loadeverything($blurb, $website, $phone, $level, $filename, $w1, $w2, $w3, $h1, $h2, $parent, $names, $menustr01, $menustr02, $footerstr01, $largepic, $extrastr, $extranumber )
		{
			/* $extrastr and $extranumber are passed down as arrays for future use. By using arrays there will be no limit to the 
			   number of new strings and numbers that could be invented in the future. I suppose one large array could be used for all the 
			   variables but then you would lose the meaningful names of the variables. */
			
			/*If ($level ==2)
			{
				global $parent01;
				$parent = $parent01;
			}
			*/
			
			/* These values for the drop down menu. Look at making this more general.......*/
			//$menuValues = array("Shops", "Eating Out", "Bars & Music", "Accommodation", "Dunfanaghy Area", "Landscape", "Sport & Leisure", "Health & Beauty", "Arts & Crafts", "Beaches", "Walks & Drives", "Festivals"); 	 
			$menuValues = array();	
			   
			LoadBanner();
			LoadNavigation($menuValues);
			LoadMainPage($blurb, $website, $phone, $level, $filename, $w1, $w2, $w3, $h1, $h2, $largepic );
			/* Shifted into LoadMainPage() - LoadAdvertising(); */
			LoadMenu($parent, $names, $menustr01, $menustr02 );  		
			LoadLocalEvents();
			LoadMailingList();
			LoadSponsors();
			LoadFooting($footerstr01);
			LoadScripts();
		}
		
		
		function LoadMetaData()
		{
			echo("<meta charset='utf-8'>");
			echo("<meta http-equiv='X-UA-Compatible' content='IE=edge'>");
			echo("<meta name='viewport' content='width=device-width, initial-scale=1'>");
			echo("<meta name='description' content=''>");
			echo("<meta name='author' content=''>");
		}
				
		function loadMailingList()
		{
			echo("<div class='row box'>");
			echo("	<div class='col-lg-12 text-center'>");
			echo("	<hr>");
            echo("		<h2 class='intro-text text-center'>Join Our  ");
            echo("		<strong>Mailing List</strong>");
			echo("		</h2>");
			echo("		<hr>");
			echo("		<p>Stay up to date with all the news from the Band festival, and receive information on exclusive deals running during the festival by signing up to our email mailing list now!</p>");
			echo("		<form class='form-inline smallTopPadding' action='addToMailingList.php' method='post'>");
			echo("		<div class='form-group'>");
			echo("			<label for='name'>Name &nbsp;</label>");
			echo("			<input type='text' name='nameToAdd' class='form-control'>");
			echo("		</div>");
			echo("		<div class='form-group'>");
			echo("			<label for='emailToAdd'>Email &nbsp;</label>");
			echo("			<input type='email' name='emailToAdd' class='form-control'>");
			echo("		</div>");
			echo("		<input type='submit' value='Sign Up' class='form-control'>");
			echo("		</form>");
			echo("	</div>");
			echo("</div>");
		}
				
		function loadContactForm()
		{
			echo "<form name='sentMessage' id='contactForm' novalidate>";
			echo "	<div class='row'>";
			echo "		<div class='col-md-6'>";
			echo "			<div class='form-group'>";
			echo "				<input type='text' class='form-control' placeholder='Your Name *' id='name' required data-validation-required-message='Please enter your name.'>";
			echo "				<p class='help-block text-danger'></p>";
			echo "			</div>";
			echo "			<div class='form-group'>";
			echo "				<input type='email' class='form-control' placeholder='Your Email *' id='email' required data-validation-required-message='Please enter your email address.'>";
			echo "				<p class='help-block text-danger'></p>";
			echo "			</div>";
			echo "			<div class='form-group'>";
			echo "				<input type='tel' class='form-control' placeholder='Your Phone *' id='phone' required data-validation-required-message='Please enter your phone number.'>";
			echo "				<p class='help-block text-danger'></p>";
			echo "			</div>";
			echo "		</div>";
			echo "		<div class='col-md-6'>";
			echo "			<div class='form-group'>";
			echo "				<textarea class='form-control' placeholder='Your Message *' id='message' required data-validation-required-message='Please enter a message.'></textarea>";
			echo "				<p class='help-block text-danger'></p>";
			echo "			</div>";
			echo "		</div>";
			echo "		<div class='clearfix'></div>";
			echo "		<div class='col-lg-12 text-center'>";
			echo "			<div id='success'></div>";
			echo "			<button type='submit' class='btn btn-xl'>Send Message</button>";
			echo "		</div>";
			echo "	</div>";
			echo "</form>";
		}

		function LoadShopSponsors()
		{
			echo("<div class='item active'>");
			echo("	<img class='img-responsive' src='img/majorsponsor01.png'/>");
			//	echo("	<img class='img-responsive smallImage' src='img/banner03.jpg'/>");
			echo("</div>");
			echo("<div class='item'>");
			echo("	<img class='img-responsive' src='img/majorsponsor02.png'/>");
			echo("</div>");
		}
 		function LoadSponsors()
		{
			echo ("<div class='row box'>");
            echo ("<div class=''>");
            echo ("<div class='col-lg-12'>");
                 echo("<hr>");
                   echo("<h2 class='intro-text text-center'>Please support  ");
                    echo("<strong>our other sponsors</strong>");
                    echo("</h2>");
                    echo("<hr>");
                echo("</div>");
				LoadSponsor("Other", "Sponsor", "img/othersponsor.jpg", "www.thebandfestival.com");
				LoadSponsor("Other", "Sponsor", "img/othersponsor.jpg", "www.thebandfestival.com");
				LoadSponsor("Other", "Sponsor", "img/othersponsor.jpg", "www.thebandfestival.com");
				LoadSponsor("Other", "Sponsor", "img/othersponsor.jpg", "www.thebandfestival.com");				
			echo("</div>");
			echo("</div>");
            echo("<div class='clearfix'></div>");
		}

		function LoadSponsor($titleBig, $titleSmall, $image, $filename )
		{
			
			echo("<div class='col-sm-3 text-center'>");
				 
				/* This line put in by G to create links to sponsors. */
				echo("<a href='$filename'>");  
					echo("<img class='img-responsive slightlyRoundedCorners center-block' src='$image' alt=''>");
					echo("<h3>$titleBig <br>");
					echo("<small>$titleSmall</small>");
					echo("</h3>");
				echo("</a>"); /* This line put in by G to end links to sponsors. */
				
			echo("</div>");
		}

		function LoadMenuItem($filename, $title, $image)
		{
			echo("<div class='col-sm-6 col-md-3'>");
				echo("<a href='$filename'>");
					echo("<div class='panel panel-default'>");
						echo("<div class='panel-heading'>");
							echo("<h4><center>$title</center></h4>");
						echo("</div>");
						echo("<div class='panel-body'>");
							echo("<img class='img-responsive smallImage slightlyRoundedCorners' src='$image'/>");
						echo("</div>");
					echo("</div>");
					echo("</a>");
				echo("</div>");
		}
		
		function LoadBanner()
		{
	//		echo("<div class='brand darkBackground'>Dunfanaghy Ver One Million and one</div>");
	//		echo("<div class='address-bar darkBackground'>Where the music beckons,And the mountains echo the call</div>");
	echo("<div class='darkBackground'>");
				echo("	 <div class='row brand darkBackground topRow'>");
				echo("		<div class='col-sm-3'>");
				/*echo("			<img class='center-block img-responsive deolasLogo' style='' src='img/deolaslogo2a.png'>");*/
				echo("		</div>");
				echo("		<div class='col-sm-6'>BAND</div>");
				echo("		<div class='col-sm-3'>");
				/*echo("			<img class='center-block img-responsive deolasLogo'  style='position: relative;left: 20px;' src='img/deolaslogo2a.png'>");*/
				echo("		</div>");
				echo(" </div>");
				echo("<div class='address-bar darkBackground'>Bluegrass And Nashville Dunfanaghy</div>");
	echo("		</div>");
		}
		
		function DisplayBlurb($txt1)
		{
			echo("<p>$txt1</p>");
		}
		
		function AddPageTitle($subtitle)
		{
			echo("<title>$subtitle - Bluegrass & Nashville Festival, Dunfanaghy, Donegal.</title>");
		}
		
		function LinkCssFiles()
		{
			/* Bootstrap Core CSS */
			echo("<link href='css/bootstrap.min.css' rel='stylesheet'>");

			/* Custom CSS */
			echo("<link href='css/business-casual.css' rel='stylesheet'>");
			echo("<link href='css/fonts.css' rel='stylesheet'>");
			echo("<link href='css/dunfanaghy-custom.css' rel='stylesheet'>");
		}
		
		function LoadMenu($parent, $names, $str01, $str02 )
		/* Function displays the complete menu based on the ARRAY $names
			Uses $parent to create Back button */
		{	 
			
			if (count($names) > 0) 
			{ 			
				echo("<div class='row box'>");
					echo("<div class=''>");
						echo("<div class='col-lg-12'>");
							echo("<hr>");
							echo("<h2 class='intro-text text-center'>$str01");
								$str03 = " " . $str02;
								echo("<strong>$str03</strong>");
							echo("</h2>");
							echo("<hr>");
						echo("</div>");
			
						$arrlength = count($names);
						for($x = 0; $x < $arrlength; $x++) 
						{
							/* Change names to lowercase, and remove apostrophes and spaces. */
							/* Tried using Trim function, but could not get it to work. */
							$temp = strtolower($names[$x]);
							$temp = str_replace(" ", "", $temp);
							$temp = str_replace("'", "", $temp);
							$temp = str_replace("&", "", $temp);
							$temp = str_replace("/", "", $temp);
	
							/* Create the html filename and the picture names. */
							$htmlfilename = $temp . ".php";
							$pic1 = "img/" . $temp .  "01.jpg";   
 				
							/* Make the call to load each menu item in turn */
							LoadMenuItem( $htmlfilename, $names[$x], $pic1 );
						}
						/* If the page has a parent, then load "Go Up" button */
						if (strlen($parent) > 0)
						{
							$pic1 = "img/" . $parent . "01.jpg";
							$parentfilename = $parent . ".php";
							LoadMenuItem( $parentfilename, "Back Up", $pic1 );
						}	
					echo("</div>");
				echo("</div>");
			}
		}
		
		function LoadLocalEvents()
		{
			 
		}
		
		function LoadFooting($footerstr01)
		{
			$footerstr01 = "Bluegrass & Nashville Festival, Dunfanaghy, County Donegal.";
			echo("<footer>");
			echo("<div class='container'>");
				echo("<div class='row'>");
					echo("<div class='col-lg-12 text-center'>");
						echo("<p>$footerstr01</p>");
					echo("</div>");
				echo("</div>");
			echo("</div>");
			echo("</footer>");
		}
		
		function LoadMainPage( $blurb, $ws, $phone, $level, $filename, $w1, $w2, $w3, $h1, $h2, $largepic )
		{		
			/* Set up variables for this function i.e. photos and the vaiours strings. */
				echo("<div class='container'>");
					echo("<div class='row'>");
						echo("<div class='box'>");
							echo("<div class='col-lg-12 text-center'>");
							if ($largepic==1)
							{
								$pic1 = "img/" . $filename .  "big01.jpg";							
								echo("<img class='img-responsive img-full' src='$pic1' alt=''>");
							}
							echo(" <!-- Main Carousel -->  ");
								echo("<h2 class='brand-before'>");
									echo("<small>$w1</small>");
								echo("</h2>");
								
								echo("<h1 class='brand-name'>$w2</h1>");
								
								echo("<hr class='tagline-divider'>");
								echo("<h2>");
									echo("<small>$w3");
									echo("</small>");
								echo("</h2>");
							
							echo("</div>"); 
						echo("</div>");
					echo("</div>");

			LoadAdvertising();

					
			/* If a picture required beside the main text then....... */
			if ($level <= 0)
			{
					echo("<div class='row box'>");
						echo("<div class=''>");
							echo("<div class='col-md-12'>");
								echo("<div class='col-md-8'>");
								echo("<hr>");
								echo("<h2 class='intro-text text-center'>$h1");
									$str06 = " " . $h2;
									echo("<strong>$str06</strong>");
								echo("</h2>");
								echo("<hr>");
								echo("<hr class='visible-xs'>");
							echo("</div>");
							echo("<div class='col-md-4'>");					
							echo("</div>");
							echo("<div class='col-md-8'>");
							DisplayBlurb($blurb);							
							echo("</div>");
							echo("<div class='col-md-4'>");
								echo("<div class='panel panel-default'>");
									$pic1 = "img/" . $filename . "main" . ".jpg";
									echo("<img class='img-responsive smallImage slightlyRoundedCorners' src='$pic1'/>");
								echo("</div>");
							echo("</div>");	
						echo("</div>");
					echo("</div>");		
				echo("</div>");
			} /* End of if statement */
			
			/* If NO picture required beside main text then......*/
			If ($level > 0)
			{
				echo("<div class='row'>");
					echo("<div class='box'>");
						echo("<div class='col-md-12'>");
							
							echo("<hr>");
							
							echo("<h2 class='intro-text text-center'> $h1");
								$str06 = " " . $h2;
								echo("<strong>$str06</strong>"); 
							echo("</h2>");
							echo("<hr>");
							
							echo("<hr class='visible-xs'>");
							DisplayBlurb($blurb);
							if (strlen($ws)>0 or strlen($phone)>0)
							{
								echo("<hr>");							
								if (strlen($ws)>0)
								{
									$str05 = "http://" . $ws;
									echo("<p><center><a href='$str05' target='_blank'>$ws</a></center></p>");	 
								}
								if (strlen($phone) > 0)
								{
									$str06 = "Phone: " . $phone;
									echo("<p><center>$str06</center></p>");   									
								}
								echo("<hr>");
							}
						echo("</div>");
					echo("</div>");
				echo("</div>");
			}
						
			/* If group of three pictures required then..... */
			if ($level ==2 or $level<0 )
			{
				echo("<div class='row'>");
					echo("<div class='box'>");					
					for ($i = 1; $i <= 3; $i++) 
						{					
							$pic1 = "img/" . $filename . "0" . $i . ".jpg";
							echo("<div class='col-md-4'>");
								echo("<div class='panel panel-default'>");
									echo("<img class='img-responsive smallImage' src='$pic1'/>");
								echo("</div>");
							echo("</div>");				
						}					 
					echo("</div>");
				echo("</div>");
			}
		}
		
		function LoadNavigation($menuValues)
		{
			echo("<nav class='navbar navbar-default' role='navigation'>");
				echo("<div class='container'>");
					echo("<!-- Brand and toggle get grouped for better mobile display -->");
					echo("<div class='navbar-header'>");
						echo("<button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#bs-example-navbar-collapse-1'>");
							echo("<span class='sr-only'>Toggle navigation</span>");
							echo("<span class='icon-bar'></span>");
							echo("<span class='icon-bar'></span>");
							echo("<span class='icon-bar'></span>");
						echo("</button>");
						echo("<!-- navbar-brand is hidden on larger screens, but visible when the menu is collapsed -->");
						echo("<a class='navbar-brand' href='index.php'>Dunfanaghy</a>");
					echo("</div>");
					echo("<!-- Collect the nav links, forms, and other content for toggling -->");
					echo("<div class='collapse navbar-collapse' id='bs-example-navbar-collapse-1' style='margin:0px; padding:0px;'>");
						echo("<ul class='nav navbar-nav'>");
							echo("<li>");
								echo("<a href='index.php'>Home</a>");
							echo("</li>");
							
							
							//////////Things to do menu///////////////////////
					echo("<li class='dropdown'>");
					echo("	<a href='#' class='dropdown-toggle' data-toggle='dropdown'>Menu <span class='glyphicon glyphicon-menu-down'></span></a>");
                    echo("     <ul class='dropdown-menu'>");									
					
					$arrlength = count($menuValues);
					for($x = 0; $x < $arrlength; $x++) 
					{					
							/* Change names to lowercase, and remove apostrophes and spaces. */
							/* Tried using Trim function, but could not get it to work. */
							$temp = strtolower($menuValues[$x]);
							$temp = str_replace(" ", "", $temp);
							$temp = str_replace("'", "", $temp);
							$temp = str_replace("&", "", $temp);
							$temp = str_replace("/", "", $temp);
	
							/* Create the html filename and the picture names. */
							$htmlfilename = $temp . ".php";
							//$pic1 = "img/" . $temp .  "01.jpg";   
 											echo("       <li>");
							echo("<a href='$htmlfilename'>$menuValues[$x]</a>");
							echo("        </li>");
						}
					echo("    </ul>");
                    echo("</li>");		
							
				//////////////End things to do menu//////////////////				
							echo("<li>");
								//echo(" <a href='http://www.calendarwiz.com/calendars/week.php?crd=dunfanaghy&cid%5B%5D=122991&cid%5B%5D=121303&cid%5B%5D=155840&cid%5B%5D=143437&cid%5B%5D=119954&cid%5B%5D=122439&cid%5B%5D=126647&cid%5B%5D=126649&cid%5B%5D=122767&cid%5B%5D=126650&cid%5B%5D=126651&cid%5B%5D=143542&cid%5B%5D=122765&cid%5B%5D=121301&cid%5B%5D=125179&cid%5B%5D=139849&cid%5B%5D=119958&cid%5B%5D=125257&cid%5B%5D=122764&' target='_blank'>Calendar</a>");
								echo("<a href='lineup.php'>Line Up</a>");
							echo("</li>");
							echo("<li>");
								echo("<a href='aboutdunfanaghy.php'>About Dunfanaghy</a>");
							echo("</li>");
							echo("<li>");
								echo("<a href='contactus.php'>Contact Us</a>");
							echo("</li>");					                   					
						echo("</ul>");
					echo("</div>");
					echo("<!-- /.navbar-collapse -->");
				echo("</div>");
				echo("<!-- /.container -->");
			echo("</nav>");
		}
		
		function LoadAdvertising()
		{
			// This removed temporarily while I seek advertisers, and decide the best way forward with it. 
			echo("<div class='row box'>");
            echo("<div class='banner-box'>");
                echo("<div class='col-md-12'>");
					echo("<div id='myCarousel' class='carousel slide' data-ride='carousel'>");
						echo("<!-- Wrapper for slides -->");
							echo("<div class='carousel-inner' role='listbox'>");
								LoadShopSponsors();									 
							echo("</div>");
						echo("</div>");
					echo("</div>");
				echo("</div>");
			echo("</div>");
			// End of removed section 
		}
		
		function LoadScripts()
		{
			echo("<script src='js/jquery.js'></script>");
		/*	echo("<script>");
				echo("$.get('http://donegaleventsmanager.azurewebsites.net/Events/GetEvents', function (data) {");
				echo("$('.eventLoader').removeClass('eventLoader');");
				echo("$('#target').html(data);");
				echo("});");
			echo("</script>");*/
			echo("<!-- Bootstrap Core JavaScript -->");
			echo("<script src='js/bootstrap.min.js'></script>");
		
			echo("<!-- Start Advertising Banner Carousel -->");
			echo("<script>");
				echo("$('#myCarousel').carousel({");
				echo("interval: 4000 ");
				echo("})");
			echo("</script>");
		}
		
		function ShowImage($image, $classes)
		{
			$detect = new Mobile_Detect;
			if ( $detect->isMobile() ) {
				echo("ON A MOBILE");
			}
			else {
				echo("NOT A MOBILE");
			}
		}
		
?>	
<?php
    require_once('config.php');
    require_once('jfunctions.php');
    
    $success = "False";
    if(notNullOrEmpty($_POST['emailToAdd']))
    {
        $db = getDB();
        $name = isset($_POST['nameToAdd']) ? $_POST['nameToAdd'] : "";
        $email = $_POST['emailToAdd'];

        $insert = $db->prepare("CALL InsertEmail(:name, :email)");
        $insert->bindValue(':name', $name);
        $insert->bindValue(':email', $email);
        $insert->execute();
        if($insert->rowCount())
            $success="True";
        
    }
   // redirectTo('http://dunfanaghy.info/testing/John/theBand/addedToMailingList.php?success='.$success);
    redirectTo('addedToMailingList.php?success='.$success);
?>